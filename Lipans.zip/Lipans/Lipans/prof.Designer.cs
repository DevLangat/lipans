﻿namespace Lipans
{
    partial class prof
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.profile = new System.Windows.Forms.PictureBox();
            this.pic = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.profile)).BeginInit();
            this.SuspendLayout();
            // 
            // profile
            // 
            this.profile.Location = new System.Drawing.Point(187, 73);
            this.profile.Name = "profile";
            this.profile.Size = new System.Drawing.Size(188, 165);
            this.profile.TabIndex = 127;
            this.profile.TabStop = false;
            // 
            // pic
            // 
            this.pic.Location = new System.Drawing.Point(248, 250);
            this.pic.Name = "pic";
            this.pic.Size = new System.Drawing.Size(91, 23);
            this.pic.TabIndex = 128;
            this.pic.Text = "Browse";
            this.pic.UseVisualStyleBackColor = true;
            // 
            // prof
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(563, 347);
            this.Controls.Add(this.profile);
            this.Controls.Add(this.pic);
            this.Name = "prof";
            this.Text = "prof";
            ((System.ComponentModel.ISupportInitialize)(this.profile)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox profile;
        private System.Windows.Forms.Button pic;
    }
}