﻿namespace Lipans
{
    partial class Reg
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label BirthPlaceLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Reg));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.gender = new System.Windows.Forms.ComboBox();
            this.close = new Bunifu.Framework.UI.BunifuThinButton2();
            this.save = new Bunifu.Framework.UI.BunifuThinButton2();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.InsuranceExpiry = new System.Windows.Forms.DateTimePicker();
            this.bunifuCustomLabel7 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel9 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txtInsuranceNo = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.bunifuCustomLabel10 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txtVehicleNo = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtInsuranceCo = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.bunifuCustomLabel11 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.metroPanel2 = new MetroFramework.Controls.MetroPanel();
            this.IsNotinsured = new MetroFramework.Controls.MetroRadioButton();
            this.IsInsuredRd = new MetroFramework.Controls.MetroRadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.licenseExpiry = new System.Windows.Forms.DateTimePicker();
            this.txtLicense = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.bunifuCustomLabel5 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel8 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel6 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txtemail2 = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.bunifuCustomLabel4 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.phone_tf = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtemail = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.bunifuCustomLabel12 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel3 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txtidno = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.bunifuCustomLabel2 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txtname = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.lblTime = new System.Windows.Forms.Label();
            this.lblDate = new System.Windows.Forms.Label();
            BirthPlaceLabel = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.metroPanel2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // BirthPlaceLabel
            // 
            BirthPlaceLabel.AutoSize = true;
            BirthPlaceLabel.Location = new System.Drawing.Point(3, 7);
            BirthPlaceLabel.Name = "BirthPlaceLabel";
            BirthPlaceLabel.Size = new System.Drawing.Size(202, 17);
            BirthPlaceLabel.TabIndex = 84;
            BirthPlaceLabel.Text = "Do you have Insurance policy:";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Beige;
            this.groupBox1.Controls.Add(this.gender);
            this.groupBox1.Controls.Add(this.close);
            this.groupBox1.Controls.Add(this.save);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.metroPanel2);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.bunifuCustomLabel6);
            this.groupBox1.Controls.Add(this.txtemail2);
            this.groupBox1.Controls.Add(this.bunifuCustomLabel4);
            this.groupBox1.Controls.Add(this.phone_tf);
            this.groupBox1.Controls.Add(this.txtemail);
            this.groupBox1.Controls.Add(this.bunifuCustomLabel12);
            this.groupBox1.Controls.Add(this.bunifuCustomLabel3);
            this.groupBox1.Controls.Add(this.txtidno);
            this.groupBox1.Controls.Add(this.bunifuCustomLabel2);
            this.groupBox1.Controls.Add(this.txtname);
            this.groupBox1.Controls.Add(this.bunifuCustomLabel1);
            this.groupBox1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.ForestGreen;
            this.groupBox1.Location = new System.Drawing.Point(23, 63);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(698, 584);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Users Details";
            // 
            // gender
            // 
            this.gender.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gender.BackColor = System.Drawing.Color.SeaShell;
            this.gender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.gender.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.gender.FormattingEnabled = true;
            this.gender.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Other"});
            this.gender.Location = new System.Drawing.Point(324, 208);
            this.gender.Name = "gender";
            this.gender.Size = new System.Drawing.Size(231, 25);
            this.gender.TabIndex = 124;
            // 
            // close
            // 
            this.close.ActiveBorderThickness = 1;
            this.close.ActiveCornerRadius = 20;
            this.close.ActiveFillColor = System.Drawing.Color.Red;
            this.close.ActiveForecolor = System.Drawing.Color.White;
            this.close.ActiveLineColor = System.Drawing.Color.White;
            this.close.BackColor = System.Drawing.Color.Beige;
            this.close.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("close.BackgroundImage")));
            this.close.ButtonText = "Close";
            this.close.Cursor = System.Windows.Forms.Cursors.Hand;
            this.close.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.close.ForeColor = System.Drawing.Color.SeaGreen;
            this.close.IdleBorderThickness = 1;
            this.close.IdleCornerRadius = 20;
            this.close.IdleFillColor = System.Drawing.Color.White;
            this.close.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.close.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.close.Location = new System.Drawing.Point(76, 521);
            this.close.Margin = new System.Windows.Forms.Padding(5);
            this.close.Name = "close";
            this.close.Size = new System.Drawing.Size(97, 49);
            this.close.TabIndex = 123;
            this.close.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.close.Click += new System.EventHandler(this.close_Click);
            // 
            // save
            // 
            this.save.ActiveBorderThickness = 1;
            this.save.ActiveCornerRadius = 20;
            this.save.ActiveFillColor = System.Drawing.Color.ForestGreen;
            this.save.ActiveForecolor = System.Drawing.Color.White;
            this.save.ActiveLineColor = System.Drawing.Color.LemonChiffon;
            this.save.BackColor = System.Drawing.Color.Beige;
            this.save.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("save.BackgroundImage")));
            this.save.ButtonText = "Save";
            this.save.Cursor = System.Windows.Forms.Cursors.Hand;
            this.save.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.save.ForeColor = System.Drawing.Color.SeaGreen;
            this.save.IdleBorderThickness = 1;
            this.save.IdleCornerRadius = 20;
            this.save.IdleFillColor = System.Drawing.Color.MintCream;
            this.save.IdleForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.save.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.save.Location = new System.Drawing.Point(408, 521);
            this.save.Margin = new System.Windows.Forms.Padding(5);
            this.save.Name = "save";
            this.save.Size = new System.Drawing.Size(88, 49);
            this.save.TabIndex = 122;
            this.save.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.save.Click += new System.EventHandler(this.save_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox3.Controls.Add(this.InsuranceExpiry);
            this.groupBox3.Controls.Add(this.bunifuCustomLabel7);
            this.groupBox3.Controls.Add(this.bunifuCustomLabel9);
            this.groupBox3.Controls.Add(this.txtInsuranceNo);
            this.groupBox3.Controls.Add(this.bunifuCustomLabel10);
            this.groupBox3.Controls.Add(this.txtVehicleNo);
            this.groupBox3.Controls.Add(this.txtInsuranceCo);
            this.groupBox3.Controls.Add(this.bunifuCustomLabel11);
            this.groupBox3.Location = new System.Drawing.Point(25, 365);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(667, 141);
            this.groupBox3.TabIndex = 121;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Insurance Details";
            // 
            // InsuranceExpiry
            // 
            this.InsuranceExpiry.Checked = false;
            this.InsuranceExpiry.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.InsuranceExpiry.Location = new System.Drawing.Point(310, 105);
            this.InsuranceExpiry.Name = "InsuranceExpiry";
            this.InsuranceExpiry.Size = new System.Drawing.Size(227, 23);
            this.InsuranceExpiry.TabIndex = 23;
            // 
            // bunifuCustomLabel7
            // 
            this.bunifuCustomLabel7.AutoSize = true;
            this.bunifuCustomLabel7.Font = new System.Drawing.Font("Century", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.bunifuCustomLabel7.Location = new System.Drawing.Point(306, 73);
            this.bunifuCustomLabel7.Name = "bunifuCustomLabel7";
            this.bunifuCustomLabel7.Size = new System.Drawing.Size(103, 20);
            this.bunifuCustomLabel7.TabIndex = 9;
            this.bunifuCustomLabel7.Text = "Expiry Date:";
            // 
            // bunifuCustomLabel9
            // 
            this.bunifuCustomLabel9.AutoSize = true;
            this.bunifuCustomLabel9.Font = new System.Drawing.Font("Century", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.bunifuCustomLabel9.Location = new System.Drawing.Point(306, 19);
            this.bunifuCustomLabel9.Name = "bunifuCustomLabel9";
            this.bunifuCustomLabel9.Size = new System.Drawing.Size(153, 20);
            this.bunifuCustomLabel9.TabIndex = 0;
            this.bunifuCustomLabel9.Text = "Insurance Number:";
            // 
            // txtInsuranceNo
            // 
            this.txtInsuranceNo.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtInsuranceNo.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtInsuranceNo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtInsuranceNo.HintForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtInsuranceNo.HintText = "Insurance Number";
            this.txtInsuranceNo.isPassword = false;
            this.txtInsuranceNo.LineFocusedColor = System.Drawing.Color.BlueViolet;
            this.txtInsuranceNo.LineIdleColor = System.Drawing.Color.Green;
            this.txtInsuranceNo.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtInsuranceNo.LineThickness = 3;
            this.txtInsuranceNo.Location = new System.Drawing.Point(310, 43);
            this.txtInsuranceNo.Margin = new System.Windows.Forms.Padding(4);
            this.txtInsuranceNo.Name = "txtInsuranceNo";
            this.txtInsuranceNo.Size = new System.Drawing.Size(227, 26);
            this.txtInsuranceNo.TabIndex = 1;
            this.txtInsuranceNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuCustomLabel10
            // 
            this.bunifuCustomLabel10.AutoSize = true;
            this.bunifuCustomLabel10.Font = new System.Drawing.Font("Century", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.bunifuCustomLabel10.Location = new System.Drawing.Point(15, 81);
            this.bunifuCustomLabel10.Name = "bunifuCustomLabel10";
            this.bunifuCustomLabel10.Size = new System.Drawing.Size(133, 20);
            this.bunifuCustomLabel10.TabIndex = 0;
            this.bunifuCustomLabel10.Text = "Vehicle Number:";
            // 
            // txtVehicleNo
            // 
            this.txtVehicleNo.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtVehicleNo.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtVehicleNo.ForeColor = System.Drawing.Color.Black;
            this.txtVehicleNo.HintForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtVehicleNo.HintText = "Vehicle Number";
            this.txtVehicleNo.isPassword = false;
            this.txtVehicleNo.LineFocusedColor = System.Drawing.Color.BlueViolet;
            this.txtVehicleNo.LineIdleColor = System.Drawing.Color.Green;
            this.txtVehicleNo.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtVehicleNo.LineThickness = 3;
            this.txtVehicleNo.Location = new System.Drawing.Point(12, 105);
            this.txtVehicleNo.Margin = new System.Windows.Forms.Padding(4);
            this.txtVehicleNo.Name = "txtVehicleNo";
            this.txtVehicleNo.Size = new System.Drawing.Size(220, 26);
            this.txtVehicleNo.TabIndex = 1;
            this.txtVehicleNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtInsuranceCo
            // 
            this.txtInsuranceCo.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtInsuranceCo.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtInsuranceCo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtInsuranceCo.HintForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtInsuranceCo.HintText = "Insurance Company";
            this.txtInsuranceCo.isPassword = false;
            this.txtInsuranceCo.LineFocusedColor = System.Drawing.Color.BlueViolet;
            this.txtInsuranceCo.LineIdleColor = System.Drawing.Color.Green;
            this.txtInsuranceCo.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtInsuranceCo.LineThickness = 3;
            this.txtInsuranceCo.Location = new System.Drawing.Point(12, 43);
            this.txtInsuranceCo.Margin = new System.Windows.Forms.Padding(4);
            this.txtInsuranceCo.Name = "txtInsuranceCo";
            this.txtInsuranceCo.Size = new System.Drawing.Size(220, 26);
            this.txtInsuranceCo.TabIndex = 1;
            this.txtInsuranceCo.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuCustomLabel11
            // 
            this.bunifuCustomLabel11.AutoSize = true;
            this.bunifuCustomLabel11.Font = new System.Drawing.Font("Century", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.bunifuCustomLabel11.Location = new System.Drawing.Point(8, 19);
            this.bunifuCustomLabel11.Name = "bunifuCustomLabel11";
            this.bunifuCustomLabel11.Size = new System.Drawing.Size(163, 20);
            this.bunifuCustomLabel11.TabIndex = 0;
            this.bunifuCustomLabel11.Text = "Insurance Company:";
            // 
            // metroPanel2
            // 
            this.metroPanel2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroPanel2.Controls.Add(this.IsNotinsured);
            this.metroPanel2.Controls.Add(BirthPlaceLabel);
            this.metroPanel2.Controls.Add(this.IsInsuredRd);
            this.metroPanel2.HorizontalScrollbarBarColor = true;
            this.metroPanel2.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel2.HorizontalScrollbarSize = 10;
            this.metroPanel2.Location = new System.Drawing.Point(25, 335);
            this.metroPanel2.Name = "metroPanel2";
            this.metroPanel2.Size = new System.Drawing.Size(400, 28);
            this.metroPanel2.TabIndex = 120;
            this.metroPanel2.VerticalScrollbarBarColor = true;
            this.metroPanel2.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel2.VerticalScrollbarSize = 10;
            // 
            // IsNotinsured
            // 
            this.IsNotinsured.AutoSize = true;
            this.IsNotinsured.Location = new System.Drawing.Point(319, 7);
            this.IsNotinsured.Name = "IsNotinsured";
            this.IsNotinsured.Size = new System.Drawing.Size(39, 15);
            this.IsNotinsured.TabIndex = 110;
            this.IsNotinsured.Text = "No";
            this.IsNotinsured.UseSelectable = true;
            this.IsNotinsured.CheckedChanged += new System.EventHandler(this.IsInsured);
            // 
            // IsInsuredRd
            // 
            this.IsInsuredRd.AutoSize = true;
            this.IsInsuredRd.Location = new System.Drawing.Point(238, 7);
            this.IsInsuredRd.Name = "IsInsuredRd";
            this.IsInsuredRd.Size = new System.Drawing.Size(40, 15);
            this.IsInsuredRd.TabIndex = 108;
            this.IsInsuredRd.Text = "Yes";
            this.IsInsuredRd.UseSelectable = true;
            this.IsInsuredRd.CheckedChanged += new System.EventHandler(this.IsInsured);
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox2.Controls.Add(this.licenseExpiry);
            this.groupBox2.Controls.Add(this.txtLicense);
            this.groupBox2.Controls.Add(this.bunifuCustomLabel5);
            this.groupBox2.Controls.Add(this.bunifuCustomLabel8);
            this.groupBox2.Location = new System.Drawing.Point(25, 239);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(655, 86);
            this.groupBox2.TabIndex = 119;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Drving License  Details";
            // 
            // licenseExpiry
            // 
            this.licenseExpiry.Checked = false;
            this.licenseExpiry.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.licenseExpiry.Location = new System.Drawing.Point(310, 50);
            this.licenseExpiry.Name = "licenseExpiry";
            this.licenseExpiry.Size = new System.Drawing.Size(220, 23);
            this.licenseExpiry.TabIndex = 125;
            // 
            // txtLicense
            // 
            this.txtLicense.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtLicense.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtLicense.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtLicense.HintForeColor = System.Drawing.Color.Black;
            this.txtLicense.HintText = "Driving License Nimber";
            this.txtLicense.isPassword = false;
            this.txtLicense.LineFocusedColor = System.Drawing.Color.BlueViolet;
            this.txtLicense.LineIdleColor = System.Drawing.Color.Green;
            this.txtLicense.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtLicense.LineThickness = 3;
            this.txtLicense.Location = new System.Drawing.Point(7, 43);
            this.txtLicense.Margin = new System.Windows.Forms.Padding(4);
            this.txtLicense.Name = "txtLicense";
            this.txtLicense.Size = new System.Drawing.Size(221, 30);
            this.txtLicense.TabIndex = 124;
            this.txtLicense.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuCustomLabel5
            // 
            this.bunifuCustomLabel5.AutoSize = true;
            this.bunifuCustomLabel5.Font = new System.Drawing.Font("Century", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.bunifuCustomLabel5.Location = new System.Drawing.Point(6, 19);
            this.bunifuCustomLabel5.Name = "bunifuCustomLabel5";
            this.bunifuCustomLabel5.Size = new System.Drawing.Size(134, 20);
            this.bunifuCustomLabel5.TabIndex = 9;
            this.bunifuCustomLabel5.Text = "Licence Number:";
            // 
            // bunifuCustomLabel8
            // 
            this.bunifuCustomLabel8.AutoSize = true;
            this.bunifuCustomLabel8.Font = new System.Drawing.Font("Century", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.bunifuCustomLabel8.Location = new System.Drawing.Point(306, 27);
            this.bunifuCustomLabel8.Name = "bunifuCustomLabel8";
            this.bunifuCustomLabel8.Size = new System.Drawing.Size(103, 20);
            this.bunifuCustomLabel8.TabIndex = 9;
            this.bunifuCustomLabel8.Text = "Expiry Date:";
            // 
            // bunifuCustomLabel6
            // 
            this.bunifuCustomLabel6.AutoSize = true;
            this.bunifuCustomLabel6.Font = new System.Drawing.Font("Century", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.bunifuCustomLabel6.Location = new System.Drawing.Point(321, 185);
            this.bunifuCustomLabel6.Name = "bunifuCustomLabel6";
            this.bunifuCustomLabel6.Size = new System.Drawing.Size(63, 20);
            this.bunifuCustomLabel6.TabIndex = 11;
            this.bunifuCustomLabel6.Text = "Gender";
            // 
            // txtemail2
            // 
            this.txtemail2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtemail2.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtemail2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtemail2.HintForeColor = System.Drawing.Color.Black;
            this.txtemail2.HintText = "example@gmail.com";
            this.txtemail2.isPassword = false;
            this.txtemail2.LineFocusedColor = System.Drawing.Color.BlueViolet;
            this.txtemail2.LineIdleColor = System.Drawing.Color.Green;
            this.txtemail2.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtemail2.LineThickness = 3;
            this.txtemail2.Location = new System.Drawing.Point(324, 134);
            this.txtemail2.Margin = new System.Windows.Forms.Padding(4);
            this.txtemail2.Name = "txtemail2";
            this.txtemail2.Size = new System.Drawing.Size(221, 30);
            this.txtemail2.TabIndex = 7;
            this.txtemail2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtemail2.OnValueChanged += new System.EventHandler(this.emailOptional);
            // 
            // bunifuCustomLabel4
            // 
            this.bunifuCustomLabel4.AutoSize = true;
            this.bunifuCustomLabel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.bunifuCustomLabel4.Location = new System.Drawing.Point(321, 112);
            this.bunifuCustomLabel4.Name = "bunifuCustomLabel4";
            this.bunifuCustomLabel4.Size = new System.Drawing.Size(212, 20);
            this.bunifuCustomLabel4.TabIndex = 6;
            this.bunifuCustomLabel4.Text = "Email Address Two[optional]:";
            // 
            // phone_tf
            // 
            this.phone_tf.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.phone_tf.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.phone_tf.ForeColor = System.Drawing.Color.Black;
            this.phone_tf.HintForeColor = System.Drawing.Color.Black;
            this.phone_tf.HintText = "0712345678";
            this.phone_tf.isPassword = false;
            this.phone_tf.LineFocusedColor = System.Drawing.Color.BlueViolet;
            this.phone_tf.LineIdleColor = System.Drawing.Color.Green;
            this.phone_tf.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.phone_tf.LineThickness = 3;
            this.phone_tf.Location = new System.Drawing.Point(29, 192);
            this.phone_tf.Margin = new System.Windows.Forms.Padding(4);
            this.phone_tf.Name = "phone_tf";
            this.phone_tf.Size = new System.Drawing.Size(219, 28);
            this.phone_tf.TabIndex = 5;
            this.phone_tf.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.phone_tf.OnValueChanged += new System.EventHandler(this.phone_tf_TextChanged);
            // 
            // txtemail
            // 
            this.txtemail.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtemail.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtemail.ForeColor = System.Drawing.Color.Black;
            this.txtemail.HintForeColor = System.Drawing.Color.Black;
            this.txtemail.HintText = "example@gmail.com";
            this.txtemail.isPassword = false;
            this.txtemail.LineFocusedColor = System.Drawing.Color.BlueViolet;
            this.txtemail.LineIdleColor = System.Drawing.Color.Green;
            this.txtemail.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtemail.LineThickness = 3;
            this.txtemail.Location = new System.Drawing.Point(29, 136);
            this.txtemail.Margin = new System.Windows.Forms.Padding(4);
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(219, 28);
            this.txtemail.TabIndex = 5;
            this.txtemail.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtemail.OnValueChanged += new System.EventHandler(this.Email_TextChanged);
            // 
            // bunifuCustomLabel12
            // 
            this.bunifuCustomLabel12.AutoSize = true;
            this.bunifuCustomLabel12.Font = new System.Drawing.Font("Century", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.bunifuCustomLabel12.Location = new System.Drawing.Point(24, 168);
            this.bunifuCustomLabel12.Name = "bunifuCustomLabel12";
            this.bunifuCustomLabel12.Size = new System.Drawing.Size(125, 20);
            this.bunifuCustomLabel12.TabIndex = 4;
            this.bunifuCustomLabel12.Text = "Phone Number:";
            // 
            // bunifuCustomLabel3
            // 
            this.bunifuCustomLabel3.AutoSize = true;
            this.bunifuCustomLabel3.Font = new System.Drawing.Font("Century", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.bunifuCustomLabel3.Location = new System.Drawing.Point(24, 112);
            this.bunifuCustomLabel3.Name = "bunifuCustomLabel3";
            this.bunifuCustomLabel3.Size = new System.Drawing.Size(121, 20);
            this.bunifuCustomLabel3.TabIndex = 4;
            this.bunifuCustomLabel3.Text = "Email Address:";
            // 
            // txtidno
            // 
            this.txtidno.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtidno.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtidno.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtidno.HintForeColor = System.Drawing.Color.Black;
            this.txtidno.HintText = "ID Number";
            this.txtidno.isPassword = false;
            this.txtidno.LineFocusedColor = System.Drawing.Color.BlueViolet;
            this.txtidno.LineIdleColor = System.Drawing.Color.Green;
            this.txtidno.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtidno.LineThickness = 3;
            this.txtidno.Location = new System.Drawing.Point(324, 72);
            this.txtidno.Margin = new System.Windows.Forms.Padding(4);
            this.txtidno.Name = "txtidno";
            this.txtidno.Size = new System.Drawing.Size(221, 30);
            this.txtidno.TabIndex = 3;
            this.txtidno.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuCustomLabel2
            // 
            this.bunifuCustomLabel2.AutoSize = true;
            this.bunifuCustomLabel2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.bunifuCustomLabel2.Location = new System.Drawing.Point(321, 49);
            this.bunifuCustomLabel2.Name = "bunifuCustomLabel2";
            this.bunifuCustomLabel2.Size = new System.Drawing.Size(98, 21);
            this.bunifuCustomLabel2.TabIndex = 2;
            this.bunifuCustomLabel2.Text = "ID Number:";
            // 
            // txtname
            // 
            this.txtname.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtname.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtname.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtname.HintForeColor = System.Drawing.Color.Empty;
            this.txtname.HintText = "Full Names";
            this.txtname.isPassword = false;
            this.txtname.LineFocusedColor = System.Drawing.Color.BlueViolet;
            this.txtname.LineIdleColor = System.Drawing.Color.Green;
            this.txtname.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtname.LineThickness = 3;
            this.txtname.Location = new System.Drawing.Point(28, 76);
            this.txtname.Margin = new System.Windows.Forms.Padding(4);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(220, 26);
            this.txtname.TabIndex = 1;
            this.txtname.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Century", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(24, 52);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(57, 20);
            this.bunifuCustomLabel1.TabIndex = 0;
            this.bunifuCustomLabel1.Text = "Name:";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.dater);
            // 
            // lblTime
            // 
            this.lblTime.AutoSize = true;
            this.lblTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTime.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblTime.Location = new System.Drawing.Point(506, 40);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(43, 20);
            this.lblTime.TabIndex = 124;
            this.lblTime.Text = "Time";
            this.lblTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblDate.Location = new System.Drawing.Point(459, 40);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(48, 20);
            this.lblDate.TabIndex = 125;
            this.lblDate.Text = "Date:";
            this.lblDate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Reg
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(757, 711);
            this.Controls.Add(this.lblTime);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lblDate);
            this.ForeColor = System.Drawing.Color.Lime;
            this.MaximizeBox = false;
            this.Name = "Reg";
            this.Text = "REGISTER MEMBER";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.metroPanel2.ResumeLayout(false);
            this.metroPanel2.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtemail2;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel4;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtemail;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel3;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtidno;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel2;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtname;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel5;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel6;
        private System.Windows.Forms.GroupBox groupBox2;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtLicense;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel8;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel7;
        private MetroFramework.Controls.MetroPanel metroPanel2;
        private MetroFramework.Controls.MetroRadioButton IsNotinsured;
        private MetroFramework.Controls.MetroRadioButton IsInsuredRd;
        private System.Windows.Forms.GroupBox groupBox3;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel9;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtInsuranceNo;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel10;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtVehicleNo;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtInsuranceCo;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel11;
        private Bunifu.Framework.UI.BunifuThinButton2 save;
        private Bunifu.Framework.UI.BunifuThinButton2 close;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label lblTime;
        private System.Windows.Forms.Label lblDate;
        private Bunifu.Framework.UI.BunifuMaterialTextbox phone_tf;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel12;
        private System.Windows.Forms.DateTimePicker licenseExpiry;
        private System.Windows.Forms.DateTimePicker InsuranceExpiry;
        internal System.Windows.Forms.ComboBox gender;
    }
}