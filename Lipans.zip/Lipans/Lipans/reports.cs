﻿using Microsoft.Reporting.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lipans
{
    public partial class reports : Form
    {
        SqlConnection cn;
        public DataSet1 ds;
        public SqlDataAdapter das;
        string user;
        public reports(String u)
        {
            cn = DBConnect.getConnection();
            InitializeComponent();
             user= u;
            
        }

        private void reports_Load(object sender, EventArgs e)
        {
           // MessageBox.Show("" + user);
            //reportViewer1.RefreshReport();
            ReportDataSource rptDataSource;

            reportViewer1.LocalReport.ReportPath = @"F:\Kevin\Documents\Visual Studio 2013\Projects\Lipans\Lipans\Report\Report1.rdlc";
            reportViewer1.LocalReport.DataSources.Clear();
            das = new SqlDataAdapter();
            ds = new DataSet1();
            string sql = "Select * from Members";
            das.SelectCommand = new SqlCommand(sql, cn);
            das.Fill(ds.Tables[0]);
            rptDataSource = new ReportDataSource("DataSet2", ds.Tables[0]);
            reportViewer1.LocalReport.DataSources.Add(rptDataSource);

            reportViewer1.SetDisplayMode(Microsoft.Reporting.WinForms.DisplayMode.PrintLayout);
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AdminPage ad = new AdminPage();
            this.Dispose();
            ad.Show();
        }
    }
}
