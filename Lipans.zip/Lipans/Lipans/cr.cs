﻿using CrystalDecisions.CrystalReports.Engine;
using Microsoft.Reporting.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lipans
{
    public partial class cr : Form
    {
        public cr()
        {
            InitializeComponent();
        }

        
        private void cr_Load(object sender, EventArgs e)
        {
            //ReportDataSource rptDataSource;
         string ReportPath = @"~/Report\CrystalReport1.rpt";
         ReportDocument crt = new ReportDocument();
         crt.Load(ReportPath);

         crystalReportViewer1.ReportSource=crt;
         crystalReportViewer1.Refresh();
            //reportViewer1.LocalReport.DataSources.Clear();
            //das = new SqlDataAdapter();
            //ds = new DataSet1();
            //string sql = "Select * from Members";
            //das.SelectCommand = new SqlCommand(sql, cn);
            //das.Fill(ds.Tables[0]);
            //rptDataSource = new ReportDataSource("DataSet2", ds.Tables[0]);
            //reportViewer1.LocalReport.DataSources.Add(rptDataSource);

            //reportViewer1.SetDisplayMode(Microsoft.Reporting.WinForms.DisplayMode.PrintLayout);
        }
    }
}
