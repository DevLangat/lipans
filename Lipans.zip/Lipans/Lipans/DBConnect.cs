﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Sql;
using System.Data.SqlClient;

namespace Lipans
{
   
   public static class DBConnect
    {

         public static SqlConnection getConnection()
         {
               string connectionString;
               connectionString = "Data Source=LANGAT;Initial Catalog=lipans;Integrated Security=True; MultipleActiveResultSets=true;";
                 SqlConnection con = new SqlConnection(connectionString);
                 con.Open();
                 return con;
             
             }

         

     
    }
}
