﻿namespace Lipans {
    
    
    public partial class lipansData {
    }
}
