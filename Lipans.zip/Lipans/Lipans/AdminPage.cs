﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Mail;

namespace Lipans
{
    public partial class AdminPage : MetroFramework.Forms.MetroForm
    {
        ListViewItem lst;
     
       SqlConnection cn;
        SqlDataReader dr;
        SqlCommand cm;
   
      
        private System.Threading.AutoResetEvent receiveNow;
        public System.IO.Ports.SerialPort port1;
        static System.Threading.AutoResetEvent readNow = new System.Threading.AutoResetEvent(false);
        public AdminPage()
        {
            InitializeComponent();
            cn = DBConnect.getConnection();
            timer1.Start();
            timer1.Interval = 10000;
            timer1.Enabled = true;
         
        }

        private void AdminPage_Load(object sender, EventArgs e)
        {
            getData();
            try
            {
                #region Display all available COM Ports
                cboPortName.Items.Clear();
                string[] ports = SerialPort.GetPortNames();

                // Add all port names to the combo box:
                foreach (string portt in ports)
                {
                    this.cboPortName.Items.Add(portt);
                    cboPortName.SelectedIndex = 0;
                }
                #endregion

                //Remove tab pages
                //this.tabSMSapplication.TabPages.Remove(tbSendSMS);
                //this.tabSMSapplication.TabPages.Remove(tbReadSMS);
                //this.tabSMSapplication.TabPages.Remove(tbDeleteSMS);

                //this.btnDisconnect.Enabled = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }



        private void Search(object sender, EventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            String idno = "ID Number";
            String cname = listView1.Columns[0].Name;
           // MessageBox.Show(cname);
            if (idno == cname) {
               
                fillText();

            }
            //txtPass.Text = listView1.FocusedItem.SubItems[6].Text;


        }
        public void fillText()
        {


            
            txtidNo.Text = listView1.FocusedItem.Text;
            txtName.Text = listView1.FocusedItem.SubItems[1].Text;
            txtEmail.Text = listView1.FocusedItem.SubItems[2].Text;
            txtPhone.Text = listView1.FocusedItem.SubItems[3].Text;

            txtgender.Text = listView1.FocusedItem.SubItems[4].Text;
            txtLicense.Text = listView1.FocusedItem.SubItems[5].Text;
            txtSearch.Text = txtidNo.Text;
        }

        public void getData()
        {
            try
            {

                listView1.Items.Clear();
                listView1.Columns.Clear();

                listView1.Columns.Add("ID Number","ID Number ", 100);
                listView1.Columns.Add("Full Name ", 200);
                listView1.Columns.Add("Email Address", 200);
                listView1.Columns.Add("Phone Number", 150);
                listView1.Columns.Add("Gender", 120);
                listView1.Columns.Add("Licence Number", 120);
                listView1.Columns.Add("Expiry Date", 200);



                string sql = @"Select * from members where Active='1'";
                //where FullName like '" + txtSearch.Text + "%'";
                cm = new SqlCommand(sql, cn);
                dr = cm.ExecuteReader();
                while (dr.Read())
                {
                    lst = listView1.Items.Add(dr["IDNumber"].ToString());
                    lst.SubItems.Add(dr["Name"].ToString());
                    lst.SubItems.Add(dr["Email"].ToString());
                    lst.SubItems.Add("0" + dr["Phone"].ToString());
                    lst.SubItems.Add(dr["Gender"].ToString());
                    lst.SubItems.Add(dr["License_No"].ToString());
                    lst.SubItems.Add(dr["LExpiryDate"].ToString());

                }
                dr.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public void getData1()
        {
            try
            {

                listView1.Items.Clear();
                listView1.Columns.Clear();

                listView1.Columns.Add("ID Number ", 100);
                listView1.Columns.Add("Full Name ", 200);
                listView1.Columns.Add("Email Address", 200);
                listView1.Columns.Add("Phone Number", 150);
                listView1.Columns.Add("Gender", 120);
                listView1.Columns.Add("Licence Number", 120);
                listView1.Columns.Add("Expiry Date", 200);



                string sql = @"Select * from members where Active like '1' And IDNumber like '" + txtSearch.Text + "%'";
                cm = new SqlCommand(sql, cn);
                dr = cm.ExecuteReader();
                while (dr.Read())
                {
                    lst = listView1.Items.Add(dr["IDNumber"].ToString());
                    lst.SubItems.Add(dr["Name"].ToString());
                    lst.SubItems.Add(dr["Email"].ToString());
                    lst.SubItems.Add(dr["Phone"].ToString());
                    lst.SubItems.Add(dr["Gender"].ToString());
                    lst.SubItems.Add(dr["License_No"].ToString());
                    lst.SubItems.Add(dr["LExpiryDate"].ToString());

                }
                dr.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            if (txtSearch.Text == "")
                getData();
            else
                getData1();
        }
        public void Clear()
        {
            txtName.Text = "";
            txtgender.Text = "";
            txtPhone.Text = "";
            txtEmail.Text = "";
            txtidNo.Text = "";
            txtSearch.Text = "";
            txtLicense.Text = "";

        }

        private void btnDone_Click(object sender, EventArgs e)
        {
            InsertTrail();
            this.Dispose();
            FrmAdminLogin fa = new FrmAdminLogin();
            fa.Show();
        }
        public void InsertTrail()
        {

            try
            {
                string sql = @"INSERT INTO tblLogTrail VALUES(@Dater,@Descrip,@Authority)";
                cm = new SqlCommand(sql, cn);
                cm.Parameters.AddWithValue("@Dater", lblTime.Text);
                cm.Parameters.AddWithValue("@Descrip", "User: Admin has successfully logged Out!");
                cm.Parameters.AddWithValue("@Authority", "Admin");


                cm.ExecuteNonQuery();
                //   MessageBox.Show("Record successfully saved!", "OK!", MessageBoxButtons.OK, MessageBoxIcon.Information);


            }
            catch (SqlException l)
            {
                MessageBox.Show("Re-input again. your username may already be taken!");
                MessageBox.Show(l.Message);
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            DateTime time = DateTime.Now;

            lblTime.Text = time.ToString();
            send();
        }

        private void Delete_Click(object sender, EventArgs e)
        {
            if (txtidNo.Text == "")
            {
                MessageBox.Show("Can't Delete if TextBox(es) are/is Empty", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (MessageBox.Show("Do you really want to delete this User?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.Yes)
                {
                    DeleteTrail();
                    DeleteUsers();
                }
            }
        }
        public void DeleteTrail()
        {
            try
            {
                string sql = @"INSERT INTO tblAuditTrail VALUES(@Dater,@TransacType,@Description,@Authority)";
                cm = new SqlCommand(sql, cn);
                cm.Parameters.AddWithValue("@Dater", lblTime.Text);
                cm.Parameters.AddWithValue("@TransacType", "Deletion");
                cm.Parameters.AddWithValue("@Description", "User #: " + txtidNo.Text + " has been DELETED!");
                cm.Parameters.AddWithValue("@Authority", "Admin");

                cm.ExecuteNonQuery();

            }
            catch (SqlException l)
            {
                MessageBox.Show(l.Message);
            }

        }
        public void DeleteUsers()
        {

            try
            {
                listView1.FocusedItem.Remove();
                string del = "Update members set Active='0' where IDNumber='" + txtidNo.Text + "'";
                cm = new SqlCommand(del, cn); cm.ExecuteNonQuery();

                MessageBox.Show("Successfully Deleted!");
                Clear();
                getData();

            }
            catch (Exception)
            {
                MessageBox.Show("No User to Remove", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);



            }
        }

        private void Add_Click(object sender, EventArgs e)
        {
            Reg r = new Reg();
            r.Show();
            this.Hide();
        }

        private void viewlogs_Click(object sender, EventArgs e)
        {
            Clear();
            try
            {

                listView1.Items.Clear();
                listView1.Columns.Clear();
               
                listView1.Columns.Add("MessageID ", 110);
                listView1.Columns.Add("ID Number ", 100);
                listView1.Columns.Add("Message Type ", 200);
                listView1.Columns.Add("Message ", 200);
               
                listView1.Columns.Add("Status",100);
                listView1.Columns.Add("Date", 200);



                
                string sql = @"Select * from tblMessagelogs";
                cm = new SqlCommand(sql, cn);
                dr = cm.ExecuteReader();
                while (dr.Read())
                {
                    lst = listView1.Items.Add(dr["MessageID"].ToString());
                    lst.SubItems.Add(dr["IDNumber"].ToString());
                    lst.SubItems.Add(dr["MessageType"].ToString());
                    lst.SubItems.Add(dr["Message"].ToString());
                    lst.SubItems.Add(dr["Status"].ToString());
                    lst.SubItems.Add(dr["Dater"].ToString());
                    //lst.SubItems.Add(dr["License_No"].ToString());
                    //lst.SubItems.Add(dr["Expiry_Date"].ToString());
                    
                }
                dr.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void viewUsers_Click(object sender, EventArgs e)
        {
            Clear();
            getData();
           
        }

        private void updateUser_Click(object sender, EventArgs e)
        {
            try
                {
                                    

                    string up = @"UPDATE Members SET [Phone] = '" + txtPhone.Text + "' ,[Email]='" + txtEmail.Text + "'  where [IDNumber]='" + txtidNo.Text + "'";
                    cm = new SqlCommand(up, cn);

                    cm.Parameters.AddWithValue("@Email", txtEmail.Text);
                    cm.Parameters.AddWithValue("@Phone", txtPhone.Text);
                  

                     cm.ExecuteNonQuery();
                     UpdateTrail();
                     Clear();
                     getData();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            
        }

        public void UpdateTrail()
        {

            try
            {
                string sql = @"INSERT INTO tblAuditTrail VALUES(@Dater,@TransacType,@Description,@Authority)";
                cm = new SqlCommand(sql, cn);
                cm.Parameters.AddWithValue("@Dater", lblTime.Text);
                cm.Parameters.AddWithValue("@TransacType", "Modification");
                cm.Parameters.AddWithValue("@Description", "User #: " + txtidNo.Text + " has been UPDATED!");
                cm.Parameters.AddWithValue("@Authority", "Admin");


                cm.ExecuteNonQuery();

            }
            catch (SqlException l)
            {
                MessageBox.Show(l.Message);
            }
        }
      
        public static bool IsValidEmailId(string InputEmail)
        {
            Regex regex = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
            Match match = regex.Match(InputEmail);
            if (match.Success)
                return true;
            else
                return false;
        }
        private void txtPhone_TextChanged(object sender, EventArgs e)
        {
            string telNo = txtPhone.Text;


            if (Regex.Match(telNo, @"^([\+]?254[-]?|[0])?[1-9][0-9]{8}$").Success)
            {

                txtPhone.ForeColor = Color.LawnGreen;

            }
            else
            {
                txtPhone.ForeColor = Color.Red;
            }
        }

        private void txtEmail_TextChanged(object sender, EventArgs e)
        {
            String UserEmail = txtEmail.Text;
            if (IsValidEmailId(UserEmail))
            {

                txtEmail.ForeColor = Color.LawnGreen;
            }

            else
            {
                txtEmail.ForeColor = Color.Red;

            }
        }

        private void metroButton2_Click(object sender, EventArgs e)
        {

        }
        void send()
        {
            SqlCommand com1,cm2;
            string sq1;
            DateTime date1 = DateTime.Now;
                   
            try
            {
            sq1 = " Select * from Members where (LExpiryDate -'" + date1.Date + "')>0 AND (LExpiryDate -'" + date1.Date + "')<6 and Status='0'";
           
                SqlDataReader dataR;
                com1 = new SqlCommand(sq1, cn);
                dataR = com1.ExecuteReader();
                while (dataR.Read())
                {

                    string name = dataR.GetValue(0).ToString();

                    string email = dataR.GetValue(3).ToString();
                    string idNo = dataR["IDNumber"].ToString();
                    email = dataR["Email"].ToString();
                    String mymail = "kevokipa4@gmail.com";
                    string phone;
                    string phonedb = dataR.GetValue(2).ToString();
                    phone = "0" + phonedb;
                  //  MessageBox.Show(name + " - " + email + " - " + phone);
                    string dat = dataR["LExpiryDate"].ToString();
                    DateTime dateDb = Convert.ToDateTime(dat);
                    try
                    {
                        var diff = (dateDb.Date - date1.Date).TotalDays;            
                   
                        //String abc = reg[1];
                        String meso = "Dear " + name + "Your Driving Licence will expire in " + diff + " days to come. Please consider renewing it. Call  0722199199 for assistance From Amaco Insurance";
                        string portname = cboPortName.Text;
                        port1 = EstablishConnection(portname);
                        string recievedData = ExecuteCommand("AT", 300);
                        recievedData = ExecuteCommand("AT+CMGF=1", 300);
                       String command = "AT+CMGS=\"" + phone + "\"";                                   
                       recievedData = ExecuteCommand(command, 300);
                        string message = meso;
                        command = message + char.ConvertFromUtf32(26) + "\r";
                        recievedData = ExecuteCommand(command, 300);                      
                        if (recievedData.EndsWith("\r\nOK\r\n")) recievedData = "Message sent successfully";
                        //send Email
                        String subject = "Licence Expiry Date Notification";
                       String msg = "Hello " + name + ", Your Driving Licence will expire in " + diff + " days to come. Please consider renewing it. ";
                        SmtpClient client = new SmtpClient("smtp.gmail.com", 587);//works if you have an email
                        MailMessage message1 = new MailMessage(); //creating new email object
                        message1.From = new MailAddress(mymail);//Your Email Id
                        message1.To.Add(email);//Receiver's email
                        message1.Body = msg; //body of email
                        message1.Subject = subject; // subject of email
                        client.UseDefaultCredentials = false; //Overriding default credentials
                        client.EnableSsl = true;// enabling ssl security                       
                        client.Credentials = new System.Net.NetworkCredential("lipansinsurance@gmail.com", "lipans2018"); //giving your login credentials
                        //update message logs
                        client.Send(message1);
                        DateTime date = DateTime.Now;
                        try
                        {
                            string sql = @"INSERT INTO tblMessageLogs VALUES(@IDNumber,@MessageType,@Message,@Status,@Dater)";
                            cm = new SqlCommand(sql, cn);
                            cm.Parameters.AddWithValue("@IDNumber", idNo);
                            cm.Parameters.AddWithValue("@MessageType", "Email/SMS");
                            cm.Parameters.AddWithValue("@Message", msg);
                            cm.Parameters.AddWithValue("@Status", "Sent");
                            cm.Parameters.AddWithValue("@Dater", date);
                            cm.ExecuteNonQuery();
                            // MessageBox.Show("Record successfully saved!", "OK!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        catch (SqlException l)
                        {
                            MessageBox.Show("Re-input again.");
                            MessageBox.Show(l.Message);
                        }                       
                        message = null; 

                        //update members
                        try
                        {
                            string up = @"UPDATE Members SET [Status] ='1' where [IDNumber]='" + idNo + "'";
                            cm2 = new SqlCommand(up, cn);
                            cm2.Parameters.AddWithValue("@Status", "1");
                            cm2.ExecuteNonQuery();
                        }
                        catch (Exception e)
                        {
                        //    MessageBox.Show(e.Message);
                        }
                        if (recievedData.Contains("ERROR"))
                        {
                            string recievedError = recievedData;
                            recievedError = recievedError.Trim();
                            recievedData = "Following error occured while sending the message" + recievedError;
                        }
                       // MessageBox.Show(recievedData);
                     
                    }
                     
                    catch (Exception esx)
                    {
                       
                        //Console.WriteLine("Error Message: " + e.Message.Trim() + "\r\nHit any key to Exit"); Console.ReadLine();
                    }

                    finally
                    {
                        if (port1 != null)
                        {
                            port1.Close();
                            port1.DataReceived -= new SerialDataReceivedEventHandler(DataReceived);
                            port1 = null;
                        }
                       
                    }
               
                   
              
                }
                dataR.Close(); dataR.Dispose();
            }


            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
           
        }


        #region Communication
        private SerialPort OpenPort(string portName)
        {
            SerialPort port = new SerialPort();
            port.PortName = portName;
            port.BaudRate = 115200;
            port.DataBits = 8;
            port.StopBits = StopBits.One;
            port.Parity = Parity.None;
            port.ReadTimeout = 300;
            port.WriteTimeout = 300;
            port.Encoding = Encoding.GetEncoding("iso-8859-1");
            port.DataReceived += new SerialDataReceivedEventHandler(port_DataReceived);
            port.Open();
            port.DtrEnable = true;
            port.RtsEnable = true;
            return port;
        }

        private void ClosePort(SerialPort port)
        {
            port.Close();
            port.DataReceived -= new SerialDataReceivedEventHandler(port_DataReceived);
        }

        void port_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            if (e.EventType == SerialData.Chars)
                receiveNow.Set();
        }

        private string ReadResponse(int timeout)
        {
            string buffer = string.Empty;
            do
            {
                if (receiveNow.WaitOne(timeout, false))
                {
                    string t = port1.ReadExisting();
                    buffer += t;
                }
                else
                {
                    if (buffer.Length > 0)
                        throw new ApplicationException("Response received is incomplete.");
                    else
                        throw new ApplicationException("No data received from phone.");
                }
            }
            while (!buffer.EndsWith("\r\nOK\r\n") && !buffer.EndsWith("\r\nERROR\r\n"));
            return buffer;
        }

        private string ExecCommand(string command, int responseTimeout, string errorMessage)
        {
            try
            {
                port1.DiscardOutBuffer();
                port1.DiscardInBuffer();
                receiveNow.Reset();
                port1.Write(command + "\r");

                string input = ReadResponse(responseTimeout);
                if ((input.Length == 0) || (!input.EndsWith("\r\nOK\r\n")))
                    throw new ApplicationException("No success message was received.");
                return input;
            }
            catch (Exception ex)
            {
                throw new ApplicationException(errorMessage, ex);
            }
        }
        #endregion
        #region send sms
        public string ExecuteCommand(string command, int timeout)
        {
            port1.DiscardInBuffer();
            port1.DiscardOutBuffer();
            readNow.Reset();
            port1.Write(command + "\r");
            string recieved = receive(timeout);
            return recieved;
        }
        public string receive(int timeout)
        {
            string buffer = string.Empty;
            do
            {
                if (readNow.WaitOne(timeout, false))
                {
                    string t = port1.ReadExisting();
                    buffer += t;
                }
            }
            while (!buffer.EndsWith("\r\nOK\r\n") && !buffer.EndsWith("\r\n> ") && !buffer.Contains("ERROR"));
            return buffer;
        }
        static SerialPort EstablishConnection(string portName)
        {

            SerialPort port = new SerialPort();
            port.PortName = portName;
            port.BaudRate = 115200;
            port.DataBits = 8;
            port.StopBits = StopBits.One;
            port.Parity = Parity.None;
            port.ReadTimeout = 300;
            port.WriteTimeout = 300;
            port.Encoding = Encoding.GetEncoding("iso-8859-1");
            port.DataReceived += new SerialDataReceivedEventHandler(DataReceived);
            port.Open();
            port.DtrEnable = true;
            port.RtsEnable = true;

            return port;


        }
        static void DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            if (e.EventType == SerialData.Chars) readNow.Set();
        }

        #endregion

        private void metroButton6_Click(object sender, EventArgs e)
        {
            String user = txtSearch.Text;
            cr r = new cr();
            r.Show();
            this.Hide();
        }
       
       

       

      
    }
}