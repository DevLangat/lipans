﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lipans
{
    public partial class Reg : MetroFramework.Forms.MetroForm
    {
        SqlConnection cn;
        public Reg()
        {
            InitializeComponent();
            cn = DBConnect.getConnection();
            timer1.Start();
            //MessageBox.Show("");
         InsuranceExpiry.MinDate = DateTime.Now;
            licenseExpiry.MinDate = DateTime.Now;
          
           
        }
        public void InsertMember()
        {

            SqlCommand cm;
            try
            {
                string sql = @"INSERT INTO members VALUES(@Name,@IDNumber,@Phone,@Email,@Email2,@Gender,@License_No,@Dater,@Status,@Active,@LExpiryDate)";
                cm = new SqlCommand(sql, cn);
                cm.Parameters.AddWithValue("@Name",  txtname.Text);
                cm.Parameters.AddWithValue("@IDNumber", txtidno.Text);
                cm.Parameters.AddWithValue("@Phone", phone_tf.Text);
                cm.Parameters.AddWithValue("@Email", txtemail.Text);
                cm.Parameters.AddWithValue("@Email2", txtemail2.Text);
                cm.Parameters.AddWithValue("@Gender", gender.Text);
                cm.Parameters.AddWithValue("@License_No", txtLicense.Text);

                cm.Parameters.AddWithValue("@Dater", lblTime.Text);
                cm.Parameters.AddWithValue("@Status", "0");
                cm.Parameters.AddWithValue("@Active", "1");
                cm.Parameters.AddWithValue("@LExpiryDate", licenseExpiry.Text);

                cm.ExecuteNonQuery();

                MessageBox.Show("Record successfully saved!", "OK!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }


            catch (SqlException l)
            {
                MessageBox.Show("Re-input again.");
                MessageBox.Show(l.Message);
            }
        }

        public void Insurance()
        {

            SqlCommand cm;


            try
            {
                string sql = @"INSERT INTO tblinsurance VALUES(@IDNumber,@Insurance_Number,@Insurance_Company,@Vehicle_Number,@Status,@IExpiryDate)";
                cm = new SqlCommand(sql, cn);
                cm.Parameters.AddWithValue("@IDNumber", txtidno.Text);
                cm.Parameters.AddWithValue("@Insurance_Number", txtInsuranceNo.Text);
                cm.Parameters.AddWithValue("@Insurance_Company", txtInsuranceCo.Text);
                cm.Parameters.AddWithValue("@Vehicle_Number", txtVehicleNo.Text);


                cm.Parameters.AddWithValue("@Status", "0");
                cm.Parameters.AddWithValue("@IExpiryDate", InsuranceExpiry.Text);

                cm.ExecuteNonQuery();

                MessageBox.Show("Record successfully saved!", "OK!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }


            catch (SqlException l)
            {
                MessageBox.Show("Re-input again.");
                MessageBox.Show(l.Message);
            }
        }


        private void close_Click(object sender, EventArgs e)
        {


            this.Dispose();
            AdminPage ap = new AdminPage();
            ap.Show();
        }

        private void save_Click(object sender, EventArgs e)
        {


            if (IsInsuredRd.Checked)
            {
                InsertMember();
                Insurance();
                //if (txtinsurance.Text == "" || txtvehicleNo.Text == "" || id_noTf.Text == "" || txtvehicleNo.Text == "" || first_name.Text == "" ||txtlastname.Text == "" || phone_tf.Text == "" || email_tf.Text == "")
                //{
                //    MessageBox.Show("Please Fill all the provided blanks!");
                //}
                //else
                //{

                //}
            }
            if (IsNotinsured.Checked)
            {
                //if (txtvehicleNo.Text == "" || id_noTf.Text == "" || txtvehicleNo.Text == "" || first_name.Text == "" || txtlastname.Text == "" || phone_tf.Text == "" || email_tf.Text == "")
                //{
                //    MessageBox.Show("Please Fill all the provided blanks!");
                //}
                //else
                //{
                InsertMember();

            }
        }

        private void IsInsured(object sender, EventArgs e)
        {

            if (IsInsuredRd.Checked)
            {
                txtInsuranceNo.Enabled = true;
                txtInsuranceCo.Enabled = true;
                txtVehicleNo.Enabled = true;

            }
            if (IsNotinsured.Checked)
            {

                txtInsuranceNo.Enabled = false;
                txtInsuranceCo.Enabled = false;
                txtVehicleNo.Enabled = false;
            }

        }
        private void dater(object sender, EventArgs e)
        {
            DateTime time = DateTime.Now;

           lblTime.Text = time.ToString();
        }
        protected void Email_TextChanged(object sender, EventArgs e)
        {
            String UserEmail = txtemail.Text;
          
            if (IsValidEmailId(UserEmail))
            {
                txtemail.ForeColor = Color.LawnGreen;

            }

            else
            {

                txtemail.ForeColor = Color.Red;
            }
        }
        public static bool IsValidEmailId(string InputEmail)
        {
            Regex regex = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
            Match match = regex.Match(InputEmail);
            if (match.Success)
                return true;
            else
                return false;
        }
        private void emailOptional(object sender, EventArgs e)
        {
            String UserEmail2 = txtemail2.Text;
            if (IsValidEmailId(UserEmail2))
            {

                txtemail2.ForeColor = Color.LawnGreen;
            }

            else
            {
                txtemail2.ForeColor = Color.Red;

            }
        }
        private void phone_tf_TextChanged(object sender, EventArgs e)
        {
            string telNo = phone_tf.Text;


            if (Regex.Match(telNo, @"^([\+]?254[-]?|[0])?[1-9][0-9]{8}$").Success)
            {

                phone_tf.ForeColor = Color.LawnGreen;

            }
            else
            {
                phone_tf.ForeColor = Color.Red;
            }
        }

        private void pic_Click(object sender, EventArgs e)
        {

        }
        

     
    }
}
