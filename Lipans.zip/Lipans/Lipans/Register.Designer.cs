﻿namespace Lipans
{
    partial class Register
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label label1;
            System.Windows.Forms.Label GenderLabel;
            System.Windows.Forms.Label AgeLabel;
            System.Windows.Forms.Label BirthPlaceLabel;
            System.Windows.Forms.Label label5;
            System.Windows.Forms.Label label6;
            System.Windows.Forms.Label label4;
            System.Windows.Forms.Label label8;
            System.Windows.Forms.Label label7;
            System.Windows.Forms.Label label9;
            System.Windows.Forms.Label CustomerIDLabel;
            System.Windows.Forms.Label label11;
            this.Dater = new System.Windows.Forms.Timer(this.components);
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.Panel2 = new System.Windows.Forms.Panel();
            this.id_noTf = new MetroFramework.Controls.MetroTextBox();
            this.txtlastname = new MetroFramework.Controls.MetroTextBox();
            this.first_name = new MetroFramework.Controls.MetroTextBox();
            this.lbltime = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            this.btnClose = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.email2 = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.licenseExpiry = new System.Windows.Forms.DateTimePicker();
            this.txtlicense = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtinsurance = new System.Windows.Forms.TextBox();
            this.txtinsuranceCo = new System.Windows.Forms.TextBox();
            this.txtvehicleNo = new System.Windows.Forms.TextBox();
            this.InsuranceExpiry = new System.Windows.Forms.DateTimePicker();
            this.metroPanel2 = new MetroFramework.Controls.MetroPanel();
            this.IsNotinsured = new MetroFramework.Controls.MetroRadioButton();
            this.IsInsuredRd = new MetroFramework.Controls.MetroRadioButton();
            this.gender = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.email_tf = new System.Windows.Forms.TextBox();
            this.phone_tf = new System.Windows.Forms.TextBox();
            label1 = new System.Windows.Forms.Label();
            GenderLabel = new System.Windows.Forms.Label();
            AgeLabel = new System.Windows.Forms.Label();
            BirthPlaceLabel = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            label6 = new System.Windows.Forms.Label();
            label4 = new System.Windows.Forms.Label();
            label8 = new System.Windows.Forms.Label();
            label7 = new System.Windows.Forms.Label();
            label9 = new System.Windows.Forms.Label();
            CustomerIDLabel = new System.Windows.Forms.Label();
            label11 = new System.Windows.Forms.Label();
            this.metroPanel1.SuspendLayout();
            this.Panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.metroPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            label1.AutoSize = true;
            label1.Location = new System.Drawing.Point(72, 186);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(58, 13);
            label1.TabIndex = 89;
            label1.Text = "Phone No:";
            // 
            // GenderLabel
            // 
            GenderLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            GenderLabel.AutoSize = true;
            GenderLabel.Location = new System.Drawing.Point(317, 187);
            GenderLabel.Name = "GenderLabel";
            GenderLabel.Size = new System.Drawing.Size(45, 13);
            GenderLabel.TabIndex = 88;
            GenderLabel.Text = "Gender:";
            // 
            // AgeLabel
            // 
            AgeLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            AgeLabel.AutoSize = true;
            AgeLabel.Location = new System.Drawing.Point(75, 140);
            AgeLabel.Name = "AgeLabel";
            AgeLabel.Size = new System.Drawing.Size(35, 13);
            AgeLabel.TabIndex = 82;
            AgeLabel.Text = "Email:";
            // 
            // BirthPlaceLabel
            // 
            BirthPlaceLabel.AutoSize = true;
            BirthPlaceLabel.Location = new System.Drawing.Point(3, 7);
            BirthPlaceLabel.Name = "BirthPlaceLabel";
            BirthPlaceLabel.Size = new System.Drawing.Size(151, 13);
            BirthPlaceLabel.TabIndex = 84;
            BirthPlaceLabel.Text = "Do you have Insurance policy:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new System.Drawing.Point(287, 32);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(101, 13);
            label5.TabIndex = 116;
            label5.Text = "Insurance Company";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new System.Drawing.Point(6, 74);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(62, 13);
            label6.TabIndex = 115;
            label6.Text = "Vehicle No:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new System.Drawing.Point(6, 32);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(74, 13);
            label4.TabIndex = 84;
            label4.Text = "Insurance No:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new System.Drawing.Point(284, 74);
            label8.Name = "label8";
            label8.Size = new System.Drawing.Size(114, 13);
            label8.TabIndex = 114;
            label8.Text = "Insurance Expiry Date:";
            // 
            // label7
            // 
            label7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            label7.AutoSize = true;
            label7.Location = new System.Drawing.Point(7, 24);
            label7.Name = "label7";
            label7.Size = new System.Drawing.Size(64, 13);
            label7.TabIndex = 120;
            label7.Text = "License No:";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new System.Drawing.Point(298, 25);
            label9.Name = "label9";
            label9.Size = new System.Drawing.Size(104, 13);
            label9.TabIndex = 123;
            label9.Text = "License Expiry Date:";
            // 
            // CustomerIDLabel
            // 
            CustomerIDLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            CustomerIDLabel.AutoSize = true;
            CustomerIDLabel.Location = new System.Drawing.Point(72, 86);
            CustomerIDLabel.Name = "CustomerIDLabel";
            CustomerIDLabel.Size = new System.Drawing.Size(64, 13);
            CustomerIDLabel.TabIndex = 119;
            CustomerIDLabel.Text = " ID Number:";
            // 
            // label11
            // 
            label11.Anchor = System.Windows.Forms.AnchorStyles.None;
            label11.AutoSize = true;
            label11.Location = new System.Drawing.Point(307, 136);
            label11.Name = "label11";
            label11.Size = new System.Drawing.Size(83, 13);
            label11.TabIndex = 121;
            label11.Text = "Email2 Optional:";
            // 
            // Dater
            // 
            this.Dater.Tick += new System.EventHandler(this.dater);
            // 
            // metroPanel1
            // 
            this.metroPanel1.BackColor = System.Drawing.Color.Beige;
            this.metroPanel1.Controls.Add(this.Panel2);
            this.metroPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroPanel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(20, 60);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(722, 569);
            this.metroPanel1.TabIndex = 0;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // Panel2
            // 
            this.Panel2.BackColor = System.Drawing.Color.Beige;
            this.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Panel2.Controls.Add(this.id_noTf);
            this.Panel2.Controls.Add(this.txtlastname);
            this.Panel2.Controls.Add(this.first_name);
            this.Panel2.Controls.Add(this.lbltime);
            this.Panel2.Controls.Add(this.panel4);
            this.Panel2.Controls.Add(label11);
            this.Panel2.Controls.Add(this.email2);
            this.Panel2.Controls.Add(CustomerIDLabel);
            this.Panel2.Controls.Add(this.groupBox2);
            this.Panel2.Controls.Add(this.groupBox1);
            this.Panel2.Controls.Add(this.metroPanel2);
            this.Panel2.Controls.Add(this.gender);
            this.Panel2.Controls.Add(this.label10);
            this.Panel2.Controls.Add(AgeLabel);
            this.Panel2.Controls.Add(this.email_tf);
            this.Panel2.Controls.Add(GenderLabel);
            this.Panel2.Controls.Add(label1);
            this.Panel2.Controls.Add(this.phone_tf);
            this.Panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Panel2.ForeColor = System.Drawing.Color.Black;
            this.Panel2.Location = new System.Drawing.Point(0, 0);
            this.Panel2.Name = "Panel2";
            this.Panel2.Size = new System.Drawing.Size(722, 569);
            this.Panel2.TabIndex = 18;
            // 
            // id_noTf
            // 
            // 
            // 
            // 
            this.id_noTf.CustomButton.Image = null;
            this.id_noTf.CustomButton.Location = new System.Drawing.Point(157, 1);
            this.id_noTf.CustomButton.Name = "";
            this.id_noTf.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.id_noTf.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.id_noTf.CustomButton.TabIndex = 1;
            this.id_noTf.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.id_noTf.CustomButton.UseSelectable = true;
            this.id_noTf.CustomButton.Visible = false;
            this.id_noTf.Lines = new string[0];
            this.id_noTf.Location = new System.Drawing.Point(149, 84);
            this.id_noTf.MaxLength = 32767;
            this.id_noTf.Name = "id_noTf";
            this.id_noTf.PasswordChar = '\0';
            this.id_noTf.PromptText = "ID Number";
            this.id_noTf.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.id_noTf.SelectedText = "";
            this.id_noTf.SelectionLength = 0;
            this.id_noTf.SelectionStart = 0;
            this.id_noTf.ShortcutsEnabled = true;
            this.id_noTf.Size = new System.Drawing.Size(179, 23);
            this.id_noTf.TabIndex = 127;
            this.id_noTf.UseSelectable = true;
            this.id_noTf.WaterMark = "ID Number";
            this.id_noTf.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.id_noTf.WaterMarkFont = new System.Drawing.Font("Century Gothic", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // txtlastname
            // 
            // 
            // 
            // 
            this.txtlastname.CustomButton.Image = null;
            this.txtlastname.CustomButton.Location = new System.Drawing.Point(160, 1);
            this.txtlastname.CustomButton.Name = "";
            this.txtlastname.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtlastname.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtlastname.CustomButton.TabIndex = 1;
            this.txtlastname.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtlastname.CustomButton.UseSelectable = true;
            this.txtlastname.CustomButton.Visible = false;
            this.txtlastname.Lines = new string[0];
            this.txtlastname.Location = new System.Drawing.Point(363, 35);
            this.txtlastname.MaxLength = 32767;
            this.txtlastname.Name = "txtlastname";
            this.txtlastname.PasswordChar = '\0';
            this.txtlastname.PromptText = "Last Name";
            this.txtlastname.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtlastname.SelectedText = "";
            this.txtlastname.SelectionLength = 0;
            this.txtlastname.SelectionStart = 0;
            this.txtlastname.ShortcutsEnabled = true;
            this.txtlastname.Size = new System.Drawing.Size(182, 23);
            this.txtlastname.TabIndex = 126;
            this.txtlastname.UseSelectable = true;
            this.txtlastname.WaterMark = "Last Name";
            this.txtlastname.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtlastname.WaterMarkFont = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // first_name
            // 
            // 
            // 
            // 
            this.first_name.CustomButton.Image = null;
            this.first_name.CustomButton.Location = new System.Drawing.Point(157, 1);
            this.first_name.CustomButton.Name = "";
            this.first_name.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.first_name.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.first_name.CustomButton.TabIndex = 1;
            this.first_name.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.first_name.CustomButton.UseSelectable = true;
            this.first_name.CustomButton.Visible = false;
            this.first_name.Lines = new string[0];
            this.first_name.Location = new System.Drawing.Point(149, 35);
            this.first_name.MaxLength = 32767;
            this.first_name.Name = "first_name";
            this.first_name.PasswordChar = '\0';
            this.first_name.PromptText = "First Name";
            this.first_name.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.first_name.SelectedText = "";
            this.first_name.SelectionLength = 0;
            this.first_name.SelectionStart = 0;
            this.first_name.ShortcutsEnabled = true;
            this.first_name.Size = new System.Drawing.Size(179, 23);
            this.first_name.TabIndex = 125;
            this.first_name.UseSelectable = true;
            this.first_name.WaterMark = "First Name";
            this.first_name.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.first_name.WaterMarkFont = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // lbltime
            // 
            this.lbltime.AutoSize = true;
            this.lbltime.Location = new System.Drawing.Point(519, 0);
            this.lbltime.Name = "lbltime";
            this.lbltime.Size = new System.Drawing.Size(0, 13);
            this.lbltime.TabIndex = 124;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Beige;
            this.panel4.Controls.Add(this.metroButton1);
            this.panel4.Controls.Add(this.btnClose);
            this.panel4.Controls.Add(this.button1);
            this.panel4.Location = new System.Drawing.Point(2, 518);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(720, 49);
            this.panel4.TabIndex = 123;
            // 
            // metroButton1
            // 
            this.metroButton1.BackColor = System.Drawing.Color.LightGreen;
            this.metroButton1.ForeColor = System.Drawing.Color.White;
            this.metroButton1.Location = new System.Drawing.Point(554, 5);
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.Size = new System.Drawing.Size(68, 24);
            this.metroButton1.TabIndex = 20;
            this.metroButton1.Text = "Save";
            this.metroButton1.UseCustomBackColor = true;
            this.metroButton1.UseCustomForeColor = true;
            this.metroButton1.UseSelectable = true;
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.Red;
            this.btnClose.ForeColor = System.Drawing.Color.White;
            this.btnClose.Location = new System.Drawing.Point(197, 4);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(65, 25);
            this.btnClose.TabIndex = 10;
            this.btnClose.Text = "&Close";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.BackColor = System.Drawing.Color.ForestGreen;
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(385, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(77, 25);
            this.button1.TabIndex = 19;
            this.button1.Text = "New";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // email2
            // 
            this.email2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.email2.Location = new System.Drawing.Point(396, 133);
            this.email2.Name = "email2";
            this.email2.Size = new System.Drawing.Size(166, 20);
            this.email2.TabIndex = 122;
            this.email2.TextChanged += new System.EventHandler(this.emailOptional);
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox2.Controls.Add(label9);
            this.groupBox2.Controls.Add(this.licenseExpiry);
            this.groupBox2.Controls.Add(label7);
            this.groupBox2.Controls.Add(this.txtlicense);
            this.groupBox2.Location = new System.Drawing.Point(73, 231);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(628, 62);
            this.groupBox2.TabIndex = 118;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Drving License  Details";
            // 
            // licenseExpiry
            // 
            this.licenseExpiry.Checked = false;
            this.licenseExpiry.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.licenseExpiry.Location = new System.Drawing.Point(408, 23);
            this.licenseExpiry.Name = "licenseExpiry";
            this.licenseExpiry.Size = new System.Drawing.Size(172, 20);
            this.licenseExpiry.TabIndex = 122;
            // 
            // txtlicense
            // 
            this.txtlicense.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.txtlicense.Location = new System.Drawing.Point(79, 21);
            this.txtlicense.Name = "txtlicense";
            this.txtlicense.Size = new System.Drawing.Size(200, 20);
            this.txtlicense.TabIndex = 121;
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox1.Controls.Add(label8);
            this.groupBox1.Controls.Add(label4);
            this.groupBox1.Controls.Add(label6);
            this.groupBox1.Controls.Add(label5);
            this.groupBox1.Controls.Add(this.txtinsurance);
            this.groupBox1.Controls.Add(this.txtinsuranceCo);
            this.groupBox1.Controls.Add(this.txtvehicleNo);
            this.groupBox1.Controls.Add(this.InsuranceExpiry);
            this.groupBox1.Location = new System.Drawing.Point(75, 361);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(628, 100);
            this.groupBox1.TabIndex = 113;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Insurance Details";
            // 
            // txtinsurance
            // 
            this.txtinsurance.Enabled = false;
            this.txtinsurance.Location = new System.Drawing.Point(86, 29);
            this.txtinsurance.Name = "txtinsurance";
            this.txtinsurance.Size = new System.Drawing.Size(194, 20);
            this.txtinsurance.TabIndex = 85;
            // 
            // txtinsuranceCo
            // 
            this.txtinsuranceCo.Enabled = false;
            this.txtinsuranceCo.Location = new System.Drawing.Point(404, 29);
            this.txtinsuranceCo.Name = "txtinsuranceCo";
            this.txtinsuranceCo.Size = new System.Drawing.Size(184, 20);
            this.txtinsuranceCo.TabIndex = 119;
            // 
            // txtvehicleNo
            // 
            this.txtvehicleNo.Enabled = false;
            this.txtvehicleNo.Location = new System.Drawing.Point(80, 71);
            this.txtvehicleNo.Name = "txtvehicleNo";
            this.txtvehicleNo.Size = new System.Drawing.Size(200, 20);
            this.txtvehicleNo.TabIndex = 118;
            // 
            // InsuranceExpiry
            // 
            this.InsuranceExpiry.Checked = false;
            this.InsuranceExpiry.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.InsuranceExpiry.Location = new System.Drawing.Point(404, 71);
            this.InsuranceExpiry.Name = "InsuranceExpiry";
            this.InsuranceExpiry.Size = new System.Drawing.Size(184, 20);
            this.InsuranceExpiry.TabIndex = 22;
            // 
            // metroPanel2
            // 
            this.metroPanel2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroPanel2.Controls.Add(this.IsNotinsured);
            this.metroPanel2.Controls.Add(BirthPlaceLabel);
            this.metroPanel2.Controls.Add(this.IsInsuredRd);
            this.metroPanel2.HorizontalScrollbarBarColor = true;
            this.metroPanel2.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel2.HorizontalScrollbarSize = 10;
            this.metroPanel2.Location = new System.Drawing.Point(75, 315);
            this.metroPanel2.Name = "metroPanel2";
            this.metroPanel2.Size = new System.Drawing.Size(324, 28);
            this.metroPanel2.TabIndex = 111;
            this.metroPanel2.VerticalScrollbarBarColor = true;
            this.metroPanel2.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel2.VerticalScrollbarSize = 10;
            // 
            // IsNotinsured
            // 
            this.IsNotinsured.AutoSize = true;
            this.IsNotinsured.Location = new System.Drawing.Point(256, 5);
            this.IsNotinsured.Name = "IsNotinsured";
            this.IsNotinsured.Size = new System.Drawing.Size(39, 15);
            this.IsNotinsured.TabIndex = 110;
            this.IsNotinsured.Text = "No";
            this.IsNotinsured.UseSelectable = true;
            this.IsNotinsured.CheckedChanged += new System.EventHandler(this.IsInsured);
            // 
            // IsInsuredRd
            // 
            this.IsInsuredRd.AutoSize = true;
            this.IsInsuredRd.Location = new System.Drawing.Point(182, 5);
            this.IsInsuredRd.Name = "IsInsuredRd";
            this.IsInsuredRd.Size = new System.Drawing.Size(40, 15);
            this.IsInsuredRd.TabIndex = 108;
            this.IsInsuredRd.Text = "Yes";
            this.IsInsuredRd.UseSelectable = true;
            this.IsInsuredRd.CheckedChanged += new System.EventHandler(this.IsInsured);
            // 
            // gender
            // 
            this.gender.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gender.BackColor = System.Drawing.Color.SeaShell;
            this.gender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.gender.FormattingEnabled = true;
            this.gender.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Other"});
            this.gender.Location = new System.Drawing.Point(394, 187);
            this.gender.Name = "gender";
            this.gender.Size = new System.Drawing.Size(121, 21);
            this.gender.TabIndex = 101;
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(75, 40);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(38, 13);
            this.label10.TabIndex = 100;
            this.label10.Text = "Name:";
            // 
            // email_tf
            // 
            this.email_tf.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.email_tf.Location = new System.Drawing.Point(149, 137);
            this.email_tf.Name = "email_tf";
            this.email_tf.Size = new System.Drawing.Size(137, 20);
            this.email_tf.TabIndex = 83;
            this.email_tf.TextChanged += new System.EventHandler(this.Email_TextChanged);
            // 
            // phone_tf
            // 
            this.phone_tf.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.phone_tf.Location = new System.Drawing.Point(149, 186);
            this.phone_tf.Name = "phone_tf";
            this.phone_tf.Size = new System.Drawing.Size(134, 20);
            this.phone_tf.TabIndex = 90;
            this.phone_tf.TextChanged += new System.EventHandler(this.phone_tf_TextChanged);
            // 
            // Register
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(762, 649);
            this.Controls.Add(this.metroPanel1);
            this.ForeColor = System.Drawing.Color.White;
            this.Name = "Register";
            this.Text = "REGISTER USERS";
            this.TransparencyKey = System.Drawing.Color.Black;
            this.Load += new System.EventHandler(this.Register_Load);
            this.metroPanel1.ResumeLayout(false);
            this.Panel2.ResumeLayout(false);
            this.Panel2.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.metroPanel2.ResumeLayout(false);
            this.metroPanel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Timer Dater;
        private MetroFramework.Controls.MetroPanel metroPanel1;
        internal System.Windows.Forms.Panel Panel2;
        internal System.Windows.Forms.Panel panel4;
        private MetroFramework.Controls.MetroButton metroButton1;
        internal System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button button1;
        internal System.Windows.Forms.TextBox email2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DateTimePicker licenseExpiry;
        internal System.Windows.Forms.TextBox txtlicense;
        private System.Windows.Forms.GroupBox groupBox1;
        internal System.Windows.Forms.TextBox txtinsurance;
        internal System.Windows.Forms.TextBox txtinsuranceCo;
        internal System.Windows.Forms.TextBox txtvehicleNo;
        private System.Windows.Forms.DateTimePicker InsuranceExpiry;
        private MetroFramework.Controls.MetroPanel metroPanel2;
        private MetroFramework.Controls.MetroRadioButton IsNotinsured;
        private MetroFramework.Controls.MetroRadioButton IsInsuredRd;
        internal System.Windows.Forms.ComboBox gender;
        internal System.Windows.Forms.Label label10;
        internal System.Windows.Forms.TextBox email_tf;
        internal System.Windows.Forms.TextBox phone_tf;
        private System.Windows.Forms.Label lbltime;
        private MetroFramework.Controls.MetroTextBox first_name;
        private MetroFramework.Controls.MetroTextBox id_noTf;
        private MetroFramework.Controls.MetroTextBox txtlastname;
    }
}